<!DOCTYPE html>
<html>

<head>
    <title>ItsolutionStuff.com</title>
</head>

<body>

    <h1>{{ $details['title'] }}</h1>
    <span>Vui lòng click vào <a href="{{$details['link']}}">đây</a> để kích hoạt tài khoản</span>
    <p>Thank you</p>
</body>

</html>
